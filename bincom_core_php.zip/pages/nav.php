<nav class="navbar navbar-expand-lg bg-success">
            <div class="container-fluid">
              <a class="navbar-brand text-white" href="../index.php">Bincom PHP test</a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                  <li class="nav-item">
                    <a class="nav-link active text-white" aria-current="page" href="../pages/q1.php">Question 1</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link text-white" href="../pages/q2.php">Question 2</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link text-white" href="../pages/q3.php">Question 3</a>
                  </li>

                </ul>
              </div>
            </div>
          </nav>
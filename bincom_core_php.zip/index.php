
<?php require 'header.php'; ?>


    <div id="app" class="bg-dark">

    	<?php require 'nav_home.php'; ?>  

		<div class="vh-100 bg-dark">

		<h2 class="m-4 text-white">Hi, i'm Seye Yemi-Olowolabi and i love to code 😉.</h2>


		</div>

      

    </div>

	<?php require 'footer.php'; ?>